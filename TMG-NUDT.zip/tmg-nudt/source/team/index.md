---
title: Team
---

# Current Students

PHD

- Huijun Liu｜Artificial Intelligence Security｜liuhuijun[at]nudt.edu.cn
- Yongtao Tang｜Information Extraction｜tangyongtao18[at]nudt.edu.cn
- Shezheng Song｜Text Summarization｜ssz614[at]nudt.edu.cn
- Xiaopeng Li | Refreshing LLM| xiaopengli[at]nudt.edu.cn
- Xi Wang | LLM Security | wx2023[at]nudt.edu.cn

Master

- Miaomiao Li｜Artificial Intelligence Security｜limiaomiao21[at]nudt.edu.cn
- Chuang Zhang | Operating System and Knowledge Graph | -
- Binrui Zeng | Artificial Intelligence for Operating System | zengbinrui[at]nudt.edu.cn
- Zhilong Liu | Artificial Intelligence for Operating System | liuzhilong23[at]nudt.edu.cn
- Xinran Hong | Artificial Intelligence for Operating System | hongxinran[at]nudt.edu.cn
- Zhuoyi Huang | Artificial Intelligence for Operating System | 1586699654[at]qq.com

# Graduated Students

PHD 

- 2022 (2018.09 - 2022.06)

  -  Bin Ji |Postdoc in National University of Singapore｜Information Extraction｜jibin[at]nudt.edu.cn

- 2021（2017.09-2021.12）

  - Zibo Yi｜Department in Beijing，Work｜Artificial Intelligence Security｜yizibo14[at]nudt.edu.cn

  - Shaoduo Gan｜Department in Beijing，Work｜Distributed Machine Learning｜ganshaoduo[at]nudt.edu.cn

Master

- 2023 (2020.09-2023.03)
  - Jing Yang｜HuaWei (Changsha｜ Information Extraction｜yangjing2036[at]126.com
  - Mengxue Du｜HuaWei (Wuhan)  ｜ Information Retrieval｜dumengxuenudt[at]nudt.edu.cn
  - Xi Deng｜BYD (Xi'An)｜Text Assessment｜deng[at]nudt.edu.cn

- 2022 (2019.09-2022.06)
  - Wuhang Lin｜NetEase(网易) SSP offer｜Text Summarization｜wuhanglin[at]nudt.edu.cn
  
- 2021（2019.09-2021.12）

  - Hao xu｜Department in Guangdong，Work｜ Web Operating System｜ xuhao19[at]nudt.edu.cn

- 2020（2018.09-2021.06）

  - Xiaohu Du｜Huazhong University of Science and Technology，PH.D.｜Artificial Intelligence Security | xhdu18[at]foxmail.com
    - Jianling Li｜Tianjin University，PH.D.| Text Summarization | jianlingl[at]nudt.edu.cn
    - Yongtao Tang｜National University of Defense Technology，PH.D.| Information Extraction｜tangyongtao18[at]nudt.edu.cn
    - Yijia Liu｜Head office of Changsha Bank，Work| Information Extraction｜

- 2019（2017.06-2019.12）
  - Dongyang Liang｜Department in Zhejiang，Work｜Science and Technology Literature Mining｜liangdongyang10[at]yeah.net

- 2018（2015.9-2018.6）
  - Lu Si｜Tsinghua University，PH.D.｜Big Data and Knowledge Graph｜lusi[at]ubuntukylin.com
  - Jie Lin｜Department in Sichuan，Work｜Big Data and Knowledge Graph｜mr_lin0215[at]163.com

- 2017（2014.9-2017.6）
  - Shaoduo Gan｜Eidgenössische Technische Hochschule Zürich，PH.D.｜Distributed Machine Learning｜ganshaoduo[at]nudt.edu.cn
  - Zibo Yi｜National University of Defense Technology，PH.D.｜Artificial Intelligence Security｜yizibo14[at]nudt.edu.cn
  - Qi Zhang｜Department in Guangdong，Work｜Distributed Operating System｜
  - Qintao Shen｜Institute of Information Engineering，Chinese Academy of Sciences，PH.D.｜System Security｜

