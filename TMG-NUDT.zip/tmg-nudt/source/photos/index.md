---
title: Photos
---

> 银河后楼小伙伴们的~(学习)~娱乐日常！

[![q68AyR.md.jpg](https://s1.ax1x.com/2022/03/29/q68AyR.md.jpg)](https://imgtu.com/i/q68AyR)

课题组自建知识库（持续更新中....）

[![pigpkYd.jpg](./feishu.png)

# 2023

## ～中文信息学会～（北京游玩）

## ~ CCF中国软件大会 ~（上海游玩）
[![pigpkYd.jpg](https://z1.ax1x.com/2023/12/07/pigpkYd.jpg)](https://imgse.com/i/pigpkYd)

# 2022
## 火锅！火锅！
[![q6lYwT.md.png](https://s1.ax1x.com/2022/03/29/q6lYwT.md.png)](https://imgtu.com/i/q6lYwT)



## “工位一赏”
[![q6Gqrn.jpg](https://s1.ax1x.com/2022/03/29/q6Gqrn.jpg)](https://imgtu.com/i/q6Gqrn)

# 2021
## “百果园”欢送毕业生
[![q6tFN6.jpg](https://s1.ax1x.com/2022/03/29/q6tFN6.jpg)](https://imgtu.com/i/q6tFN6)
[![q6YtTx.jpg](https://s1.ax1x.com/2022/03/29/q6YtTx.jpg)](https://imgtu.com/i/q6YtTx)

## ~ADL讲习班~（北京游玩）
[![q6GT2Q.jpg](https://s1.ax1x.com/2022/03/29/q6GT2Q.jpg)](https://imgtu.com/i/q6GT2Q)
[![q6G8CF.jpg](https://s1.ax1x.com/2022/03/29/q6G8CF.jpg)](https://imgtu.com/i/q6G8CF)



## 留校过年的团建
[![q6QjL6.md.jpg](https://s1.ax1x.com/2022/03/29/q6QjL6.md.jpg)](https://imgtu.com/i/q6QjL6)
[![q6QzdO.md.jpg](https://s1.ax1x.com/2022/03/29/q6QzdO.md.jpg)](https://imgtu.com/i/q6QzdO)
[![q6QOQ1.md.jpg](https://s1.ax1x.com/2022/03/29/q6QOQ1.md.jpg)](https://imgtu.com/i/q6QOQ1)



# 2020
##  ~CCKS20会议~（南昌游玩）
[![q6l1ln.md.jpg](https://s1.ax1x.com/2022/03/29/q6l1ln.md.jpg)](https://imgtu.com/i/q6l1ln)

## 火锅！火锅！



